<template>
  <div class="chart">
    <h1>Call Third Party API's</h1>
    <chart></chart>
  </div>
</template>

<script>
import Chart from "./CallAPI.js";
export default {
  components: {
    Chart
  }
};
</script>

<style>
</style>