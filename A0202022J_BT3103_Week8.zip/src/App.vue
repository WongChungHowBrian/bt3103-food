<template>
  <div id="app">
    <h1> Brian's Kopitiam </h1>
    
    <router-view></router-view> 

  </div>
</template>

<script>
export default {


}
</script>

<style scoped>
h1 {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  text-align: center;
  margin: 20px;
  padding: 20px;
  font-size:40px;
  color:orchid;
  background-color: lightslategray;
}
</style>
